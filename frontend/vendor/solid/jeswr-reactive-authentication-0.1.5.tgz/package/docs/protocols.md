---
title: Protocol support
---
<!-- AUTHORED-BY Codex GPT-6 -->

# Protocol support

Sources read on 2026-09-26: [Solid-OIDC](https://solidproject.org/TR/oidc) 0.1.0 (2022-03-28),
[Solid Protocol](https://solidproject.org/TR/protocol) 0.11.0, and the LWS drafts at
[w3c/lws-protocol@268fd25](https://github.com/w3c/lws-protocol/tree/268fd25be04dd609f8b3a9b324e99c0073c67f0f)
(2026-09-25): `lws10-core/Authentication.html`, `Authorization.html`, `Discovery.html`,
`Security-Considerations.html` (the included sections, which rendered pages can omit) and the four
`lws10-authn-*` suites. LWS documents are editor's drafts ("unofficial proposal"); support tracks that commit
and may need changes as they evolve. LWS authorization discovery additionally supports
the [23 October 2026 Working Draft](https://www.w3.org/TR/2026/WD-lws10-core-20261023/) and
[RFC 9728](https://www.rfc-editor.org/rfc/rfc9728.html); the earlier challenge remains available for
compatibility. Nothing here claims conformance certification.

## Matrix

| Protocol / suite | Credential acquisition | Exchange / access token | Presentation | Module | Test evidence |
| --- | --- | --- | --- | --- | --- |
| Solid-OIDC | Authorization code + PKCE (S256), `state`, `nonce`, silent `prompt=none` then interactive (`prompt=consent` for `offline_access`) | Access token from the OP; refresh (rotating) grants | `Authorization: DPoP` + fresh proof (`htm`, `htu`, `ath`, `jti`, RS nonce) | `DPoPTokenProvider`, `OidcSession`, `authorizationCodeGrant` | `test/solid-oidc.test.js`, `test/persistence.test.js`, browser `page`, `sw`, `popup` |
| Solid-OIDC §9 with UMA 2.0 | ID token via the Solid-OIDC session (DPoP-bound, `cnf`) | UMA grant `urn:ietf:params:oauth:grant-type:uma-ticket` with `ticket`, `claim_token` = ID token, `claim_token_format` = `http://openid.net/specs/openid-connect-core-1_0.html#IDToken`, DPoP proof with the ID token's key; metadata at `as_uri` + `/.well-known/uma2-configuration` with that profile in `uma_profiles_supported` | RPT as `DPoP` (+ proof) or `Bearer` per `token_type` | `SolidUmaTokenProvider` | `test/uma.test.js` (mock AS verifies ID token signature with jose, `webid`, `aud` `solid`, `cnf.jkt` = proof key, single-use tickets) |
| OAuth client credentials (CSS style) | Client ID/secret | Client credentials grant, DPoP-bound | `Authorization: DPoP` | `ClientCredentialsTokenProvider` | `test/components.test.js` |
| LWS core authorization | — | RFC 9728 PRM selects an AS; RFC 8693 exchange uses `resource` = storage Link. Legacy `as_uri`/`realm` enabled by default. AS metadata at `/.well-known/lws-configuration` | `Authorization: Bearer` (RFC 6750) | `LwsTokenProvider`, `lws/tokenExchange` | `test/lws.test.js`, `test/lws-resource-metadata.test.js` |
| LWS OpenID Connect suite | ID token via authorization code flow (URI `sub`, `azp` required) | subject token type `urn:ietf:params:oauth:token-type:id_token` | via LWS core | `OidcIdTokenSource` | `test/lws.test.js` (mock AS verifies signature against the OP's JWKS) |
| LWS SAML 2.0 suite | Signed assertion from the application's SAML stack (adapter) | `urn:ietf:params:oauth:token-type:saml2`, base64url assertion | via LWS core | `SamlAssertionSource` | `test/lws.test.js` (mock AS verifies the XML signature with xml-crypto; tampering and wrong audience rejected) |
| LWS self-signed, controlled identifiers | Self-issued JWT: `sub` = `iss` = `client_id`, `aud` = [AS], `iat`, `exp`, `jti`, `kid` = verification method | `urn:ietf:params:oauth:token-type:jwt` | via LWS core | `SelfIssuedJwtSource`, `createControlledIdentifierDocument` | `test/lws.test.js` (verifier dereferences the CID, selects `kid` in `authentication`) |
| LWS self-signed, did:key (discontinued draft) | As above with `sub` = `did:key` of the signing key (Ed25519 or P-256) | `urn:ietf:params:oauth:token-type:jwt` | via LWS core | `DidKeySource`, `didKeyFromPublicKey` | `test/lws.test.js` (independent decoder with multiformats + @noble/curves; spec vectors) |
| OAuth 2.0 / OpenID Connect (generic) | Authorization code + S256 PKCE for a registered client (public, or confidential server-side); state, `iss`, redirect URI checked; with `openid`: nonce, ID token issuer/audience | Refresh (rotating or not); RFC 8707 `resource` / `audience` | `Authorization: Bearer` for configured `resources` only | `OAuthCodeSource`, `OAuthBearerTokenProvider` | `test/oauth.test.js` (local OAuth/OIDC fixture with opaque tokens) |
| Google APIs (browser) | Google Identity Services token model (injected SDK), click-driven | No refresh token; renewal needs a user gesture | Bearer | `GoogleTokenSource` | `test/oauth-sdk.test.js`, `test/types/google.ts` (community GIS types), browser `google-adapter` (mock SDK) |
| Microsoft Entra ID / Graph (browser) | MSAL.js (injected SDK) | `acquireTokenSilent` (+ `forceRefresh`), interactive only for interaction-required errors | Bearer | `MsalTokenSource` | `test/oauth-sdk.test.js` (SDK fake), `test/types/msal.ts` (real MSAL types) |
| Any other protocol | Implement `TokenProvider` (and optionally `CredentialSource` for other RFC 8693 token types) | — | — | `examples/custom-protocol.js` | `test/lws.test.js` "extension" |

**Who validates what.** The client validates what it receives from its own identity provider (oauth4webapi:
state, `iss`, nonce, ID token claims, token responses). It never validates SAML assertions or self-issued
JWTs it sends — the authorization server does (signature, trust in the issuer, audience, validity). The test
authorization server in `test/helpers/lws.js` performs those checks with jose, xml-crypto (reading claims only
from the signed reference) and multiformats/@noble/curves, independently of the library.

## Discovery and trust

- **Challenges.** `WWW-Authenticate` is parsed per RFC 9110; challenges with duplicated parameters are dropped
  and parsing stops at malformed input. oauth4webapi has an equivalent parser but does not export it.
- **LWS RFC 9728.** A `Bearer resource_metadata="M"` challenge selects `LwsTokenProvider` only when
  the same 401 carries `Link: <S>; rel="https://www.w3.org/ns/lws#storage"` for the requested resource
  (Link anchors are respected). `resource_metadata` alone is general OAuth evidence, so other providers
  can answer it.
  M must be HTTPS (HTTP only with `http.allowInsecureRequests`) and have the request's origin.
  PRM is retrieved with `credentials: "omit"`, `redirect: "manual"` using non-reactive secure transport;
  non-success, non-JSON, any 3xx, followed or opaque redirects fail closed. Its `resource` is compared
  string-for-string to the WHATWG-serialized `Request.url` after stripping its fragment; query and
  percent-encoding are kept. The returned string is not normalized. This is the requested-resource
  rule in LWS Discovery Validation 2 and RFC 9728 §3.3 for challenge-supplied metadata.
  Existing `resolveStorageContext` verifies S's same-origin description and a containing, same-origin StorageRoot
  whose HEAD response links back to S; an exact-URL fallback is insufficient for authentication.
  Requiring the description itself to share the request's origin follows suite ADR-002 Security:
  "Description URL and StorageRoot must be same scheme+authority as the resource". This deliberately
  exceeds LWS §5.2.3, which constrains only `StorageRoot.serviceEndpoint`. Cross-origin descriptions
  are accepted only through the legacy path with an explicit `trustBindings` policy; that policy
  cannot relax the RFC 9728 description-origin check.
  `authorization_servers` must be an array with a usable issuer. Select the first entry passing
  `trustAuthorizationServer` (including policies from `trustAuthorizationServers` or `trustBindings`);
  its `ChallengeBinding.realm` is S and `resource` is the requested URL. The default trusts any listed AS
  after PRM and storage validation, including a separately hosted AS.
  Discover its LWS metadata without redirects, requiring `issuer` equality, before calling
  `CredentialSource.getCredential`. Exchange uses `resource=S` (not PRM's `resource`), subject token,
  subject token type and client ID. Access tokens are fenced and cached per AS, S and credential context
  until expiry minus 30 seconds; rejection invalidation is compare-and-remove, and `forget()` logs out.
  For both challenge forms, responses without `expires_in` are used only for the current request;
  access tokens (including JWTs) are not cached, and stored entries without an expiry are discarded.
  Validation failures acquire no credential and make no token request.
- **LWS legacy.** A `Bearer` challenge with `as_uri` and `realm` also selects `LwsTokenProvider`
  unless `legacyLwsChallenge: false` (default true). Both values come from the same
  401, so trust is anchored in the requested resource: by default the AS and the realm must be on the
  resource's origin; other bindings need `trustAuthorizationServers` (same-origin realm) or `trustBindings`
  (explicit AS/realm pairs). Only then is containment checked: by path, or under a `StorageRoot` of the
  realm's description that itself links back to that storage. RFC 9728 takes precedence when both
  forms occur with an LWS storage Link, even in separate Bearer challenges; a failed RFC 9728 validation
  never falls back. Without that Link, an enabled legacy challenge still applies.
  UMA challenges go to `SolidUmaTokenProvider`.
- **Solid.** Issuers come from the application (picker, hint, fixed) or the WebID (`solid:oidcIssuer`, the
  RDF body is canonical). With `verifyWebId`, the reported WebID must list the issuer (exact identifier
  comparison; only origin-only issuers are treated as equal with and without a trailing slash).
- **Storage context** (`resolveStorageContext`): LWS `Link rel="https://www.w3.org/ns/lws#storage"` and Solid
  `Link rel="http://www.w3.org/ns/solid/terms#storageDescription"` are both supported, never assumed
  interchangeable. Evidence counts only if the response is for the resource itself (no redirect, `anchor`
  respected), the description is same-origin, and the root confirms the binding with its own Link headers
  (LWS: same storage; Solid: `rel="type"` `pim:Storage` and the same description). Otherwise the exact URL is
  the context. Storage-context discovery never widens a static `CredentialBoundary`.
- **Automatic credential boundary** (opt-in `AutomaticCredentialBoundary`): on a 401 for an eligible URL,
  the same validated evidence (LWS description → `StorageRoot`; Solid description → confirmed `pim:Storage`
  root) from that first response's Link headers — or the URL typed `pim:Storage` itself — admits the root.
  Otherwise Solid ancestor traversal (Solid Protocol §4.1: "moving up the URI path hierarchy until the
  response includes a Link header field with `rel="type"` targeting `pim:Storage`") probes each parent with an
  unauthenticated, non-redirected `HEAD`, nearest first, within a budget; a root's own type Link suffices there.
  No verified root: no login, no credentials. Limitations: servers that do not expose `Link` via CORS, or
  answer `HEAD` on private containers without it, cannot be discovered; writes may cost one extra target
  `HEAD` (not in `"headers-only"` mode, which disables the fallback target probe and ancestor traversal but still
  fetches an advertised description and `HEAD`-confirms its root); discovered roots are memory-only (`lifetimeMs`,
  `maxRoots`) and cover their descendants until expiry or `delete`/`clear`, without re-discovering nested
  storages meanwhile; storage descriptions must be same-origin (separately hosted LWS descriptions need a
  static boundary); `eligible` is enforced on every check.
- **Solid-OIDC token audience.** Solid-OIDC access tokens are not storage-bound (the ID token audience
  includes `solid`). Sessions are nevertheless keyed per verified storage, so a storage only receives tokens
  obtained for it; the credential boundary decides which URLs may receive any token.

## Draft limitations and ambiguities

1. **ID token type spelling.** lws10-core's metadata example lists `urn:ietf:params:oauth:token-type:id-token`;
   the OpenID suite and request example use the registered `…:id_token`. We send `id_token` and accept either
   in `subject_token_types_supported`.
2. **Metadata location for issuers with paths.** The draft only names the path `/.well-known/lws-configuration`;
   for issuers with a path we insert it before the path (RFC 8414 §3.1). `issuer` must equal the selected
   AS identifier (`as_uri` for legacy challenges).
3. **`kid` form (CID suite).** CID 1.0 §3.3 retrieves verification methods by URL; the suite's example uses a
   bare `kid`. We emit the verification method's absolute URL.
4. **SAML token shape.** The suite example shows a `samlp:Response`; RFC 8693's `saml2` type is an assertion.
   We send the signed `saml:Assertion`. Obtaining it (SP-initiated SSO, bindings) is outside this library.
5. **Client identifier in token exchange.** The draft does not say how the client authenticates at the token
   endpoint. We send `client_id` (the credential's client identifier) with no client authentication.
6. **Access token type.** The draft presents access tokens as Bearer; responses with another `token_type` are
   rejected. No DPoP binding is defined for LWS access tokens.
7. **Legacy "logically contained within the realm".** Undefined beyond examples; we use path containment or a
   confirmed `StorageRoot` of the realm's description.
8. **Audience of ID tokens.** The OpenID suite says `aud` SHOULD include the AS; many OPs cannot. The default
   sends ID tokens to trusted AS bindings regardless; `requireAudience` refuses otherwise.
9. **did:key suite status.** Discontinued in favour of the CID suite (which accepts DIDs); kept because the
   brief asks for all current drafts, and because the encoding is the same.
10. **UMA claims gathering and token format.** Interactive claims gathering (`need_info` + `redirect_user`,
    `request_submitted`) is not automated; `UmaAuthorizationError` exposes the hint and the new ticket. The ID
    token is pushed unencoded (it is already a compact JWT); PCTs and RPT upgrades are not used. The UMA
    metadata `issuer` must equal `as_uri` (origin-only issuers compare with or without a trailing slash).
    The trust policy runs before the OP is resolved or any login happens; RPTs are cached per UMA server,
    resource context and session configuration (OP, redirect URI, account, scopes).
11. **Solid storage roots behind authentication.** If a server does not expose Link headers on an
    unauthenticated `HEAD` of a private root, storage grouping falls back to exact URLs (more silent logins).

## Retained compatibility exceptions

Validation is strict by default except for three workarounds kept from upstream for specific deployments.
They apply automatically **only** to these exact issuer origins, and `serverQuirks: false` (on
`OidcSession`/`DPoPTokenProvider`/`SolidUmaTokenProvider`/`ClientCredentialsTokenProvider` options) disables them:

| Issuer origin | Exception | Standard behaviour otherwise |
| --- | --- | --- |
| `https://login.inrupt.com` | `client_secret_basic` without URL-encoding the ID and secret | RFC 6749 §2.3.1 encoding |
| `https://login.inrupt.com` | `interaction_required` without the RFC 9207 `iss` parameter still triggers the interactive attempt | the response is rejected |
| `https://datapod.igrant.io`, `https://solidweb.org` | ID tokens without `nonce` accepted | `nonce` must match |

`test/quirks.test.js` checks that look-alike issuers get standard behaviour and that the switch works;
PKCE, state and nonce checks for all other issuers are exercised by `test/solid-oidc.test.js`.
