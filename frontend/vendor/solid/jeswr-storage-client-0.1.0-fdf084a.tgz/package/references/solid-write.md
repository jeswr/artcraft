<!-- AUTHORED-BY Codex GPT-6.1-Sol -->
<!-- AUTHORED-BY Claude Opus 5.5 -->
<!-- AUTHORED-BY Codex GPT-6 -->

# Solid write side

Read with [storage-client guidance](../SKILL.md) for shared contracts and Solid read behavior.

Solid write side (ADR-003 §6, T-022; implementation isolated in `src/solid-write.ts`):
- Every target, container, destination, Location and describedby URL passes `scoped(root, method,
  url)` before a request (absolute URLs, credentials redacted on scope errors). Every mutation
  target refuses queries/fragments, including empty `?`/`#`. Requests use `redirect: 'manual'`;
  unexpected 2xx/3xx are `invalid-response` and unread bodies are discarded. Only 200/201/204/205
  succeed. Errors use `failed`/`storageErrorFrom` (412 includes the response ETag, 409 is conflict,
  405 method-not-allowed, 415 unsupported-media-type, 422 bad-request).
- Transport failures are retryable `network`; aborts and all failures with a ReadableStream
  request body (including HTTP errors) are non-retryable, retaining code/status/retry delay.
  Streams pass through with `duplex: 'half'`;
  strings/Uint8Array/Blob pass directly. Abort signals are checked before/between requests.
- `write`/`writeRdf` require a nonempty string `ifMatch`; `'*'` means no Solid precondition/header.
  `patch`/`delete`/`move`/`setMetadata` require a non-'*' ETag string (TypeError before requests).
  Header values (contentType, ifMatch, Slug, patch media type) reject leading/trailing whitespace,
  CR/LF/NUL and non-ByteString with TypeError; check whitespace before comparing ifMatch to '*'.
  Content types must be valid media types (parameters allowed). `write` and resource `create`
  require contentType. Wrong option types are TypeErrors.
- PUT/PATCH/POST results use `created: status === 201`. ETag comes from the response, else a scoped
  `client.head` when `etagFollowUp` (default true). Any follow-up HEAD failure, including abort or
  redirect, yields null: the mutation already committed. `etagFollowUp: false` disables the HEAD.
- `write` PUTs Content-Type and If-Match (except '*'); a container path is method-not-allowed.
  `writeRdf` uses `serializeQuads`, default text/turtle, only WRITABLE_RDF formats. JSON-LD writing
  remains unsupported (`feature: 'rdfConneg'`, documented deviation sst-3n68).
- `create` requires a trailing-slash container; kind defaults to resource. Names must be strings,
  nonempty, neither '.' nor '..', with no slash/control characters; encode with encodeURIComponent.
  Named creates PUT the exact child (+ '/' for containers), `If-None-Match: *`; a 412 becomes
  conflict ('name taken') preserving status 412. The internal exact-URL helper accepts an already
  encoded last segment, so move never decodes a stored name (which need not be UTF-8).
- Unnamed creates POST with a crypto.getRandomValues random 16-character lowercase RFC 4648
  base32 Slug. Containers send BasicContainer Link type and empty text/turtle body; POST resources
  send Resource Link type, and null means empty body. Location is required, resolved against the
  parent, scoped, query/fragment-free, a direct child, and trailing-slash iff container. Invalid
  Location is invalid-response; its URL is never fetched or retained in the error, including its
  cause chain. The error names only the scoped container. `opts.links` is ignored: Solid types
  belong in RDF; metadata is never written implicitly (ADR's writable-describedby qualification).
- RDF patches use `buildN3Patch`'s fixed InsertDeletePatch envelope; formula order is nonempty
  where, deletes, inserts. Every triple line is serialized through rdf-serialize/n3.Writer in
  N-Triples style; the final semicolon is followed by `.\n`. Serialization reuses rdf.ts IRI
  escaping and language checks. Subjects must be NamedNode/BlankNode/Variable, predicates
  NamedNode/Variable and objects NamedNode/BlankNode/Literal/Variable. Reject non-default graphs
  and blank nodes in all N3 formulas (where/deletes/inserts).
  Solid Protocol §5.3.1 forbids blank nodes in insertions and deletions; this corrects ADR-003 §6's
  "blank nodes in inserts are allowed by CSS" remark. CSS enforces the prohibition. Variables
  must match SPARQL VARNAME minus the leading digit (start with a letter or underscore, as n3/CSS
  require) and occur in where before use in inserts/deletes. Invalid RDF is bad-request, status
  null, before any request; empty inserts+deletes is TypeError ('empty patch').
- Format choice deliberately differs from ADR §6: prefer text/n3 when advertised for text/turtle,
  or patch state is not available (undescribed default). Use application/sparql-update only when
  N3 is absent, SPARQL advertised, and there is no nonempty where/variable; emit nonempty DELETE
  DATA then INSERT DATA joined by `;\n`. Select the format before the single validation pass:
  SPARQL INSERT DATA allows insert blank nodes; where/deletes still refuse them. SPARQL retains
  deterministic collision-free blank-node relabeling (reserving `_:patch`) for stable bytes.
  Directional literals are bad-request (status null) before HTTP with SPARQL 1.1 Update, which
  cannot express their base direction. N3 Patch retains them: installed CSS 8.0.0-alpha.3 uses
  n3 2.1.1, whose N3PatchBodyParser accepts `"example"@en--ltr` with its complete term intact.
  Otherwise unsupported (`feature: 'patch'`). N3 requires every deletion to match (409),
  preserving memory conflict semantics; SPARQL DELETE DATA silently
  ignores absent triples. JSON patch requires application/json-patch+json in any advertised format
  entry; ops must be an array of objects with a valid op/string path (TypeError otherwise), sent
  with JSON.stringify. Raw patch sends validated mediaType/body. Every PATCH sends If-Match.
- `delete` refuses the root (method-not-allowed). Nonrecursive DELETE sends If-Match; recursive
  resource deletion is the same. Recursive container deletion HEAD-checks the top ETag byte-equal
  first (mismatch: 412/current ETag), walks scoped listAll, and deletes children before containers.
  Children and the final container DELETE are unconditional: child ETags are unknown and container
  membership changes its ETag. Concurrent additions can make the final DELETE conflict (409). A descendant that answers 404 is skipped, because deleting a subject also deletes its auxiliary documents (Solid Protocol §5.4); a 404 for the top container still fails.
- Solid move is emulated (features.move.detail.native false): refuse the root, require a container
  destination, reject self/subtree container cycles with conflict before requests, comparing
  percent-decoded path segments (raw segment on decoding failure; decoded slashes remain inside
  their segment). Requests retain raw path spellings. Validate/encode an explicit name
  or retain the raw source segment. Read/head the source and compare its ETag before any writes.
  Resources stream their GET body/Content-Type into PUT with If-None-Match:* then DELETE source
  with If-Match matching that GET's ETag. Source validators must be single strong entity-tags;
  missing/unusable GET ETags or missing/malformed Content-Type
  are invalid-response errors identifying the source GET, before its destination PUT.
- Container moves walk listAll recursively before writes, capped at 2000 resources including the
  top container (unsupported/feature move above the cap). Preflight inspects every container's RDF,
  including the top one, reusing the listing GET and its parsed dataset with the existing RDF body
  handling and limits. Only `ldp:contains` (any subject), and statements about that container or its
  listed members using `rdf:type` with an LDP-namespace IRI or `pim:Storage`, `dcterms:modified`, or
  a predicate in `http://www.w3.org/ns/posix/stat#` are allowed, plus `rdf:type`
  `<http://www.w3.org/ns/iana/media-types/{type}#Resource>` on listed members (file-backed CSS
  types every member with its media type). Anything else refuses the move with
  `unsupported`/feature `move`: container RDF would not be preserved. Other types, including an
  IANA class on the container itself, are refused. CSS 8.0.0-alpha.3 sources
  (under its installed package): `dist/storage/DataAccessorBasedStore.js:95–100` generates containment
  and includes child metadata; `dist/util/ResourceUtil.js:21–36` generates LDP types and
  `dcterms:modified`; `dist/storage/accessors/FileDataAccessor.js:297–305` generates `stat:mtime`
  and `stat:size`, and `:278–282` the member IANA media-type classes. Preflight HEADs every member
  to discover auxiliary exclusions and rejects missing/unusable validators for copied resources before writes;
  any supplied auxiliary-resource validator used for teardown must also be strong. No resource GET
  bodies are read during preflight. Copy breadth-first, creating containers before children and
  streaming one resource at a time without buffering. Record each GET ETag for depth-first source
  deletion: copied resources use that validator, auxiliary members use their HEAD ETag when present,
  containers remain unconditional because membership changes their ETag. Listed .acl/.acr,
  advertised describedby documents, and every scoped rel="acl" link target (WAC or ACP,
  regardless of filename) discovered during header preflight are excluded from implicit copies;
  source teardown still deletes listed auxiliary members; a 404 from one of them counts as deleted, because deleting its subject removes it (Solid Protocol §5.4). Any other source DELETE failure, including a 404 for a copied resource, still makes the move partial. The explicit move source is never
  excluded. Exclusion identity compares origin, percent-decoded path segments (raw segment on
  decoding failure), and the trailing slash; the suffix rule uses the decoded last segment.
  Requests keep their original spellings. ACLs and metadata are not copied implicitly.
  Residual race: triples added to a container after preflight are not detected, because source
  container DELETEs are unconditional.
- Copy failure rolls back completed copies deepest-first and rethrows the original error. Resource
  cleanup trusts only its own PUT-response ETag when it is exactly one strong entity-tag (no
  wildcard, weak tag, list or malformed value); follow-up HEAD observations are kept separately
  for successful results. Copies without a usable create-response ETag and their ancestors are preserved,
  reporting a partial move (conflict with the original cause). After handling copied children,
  container cleanup reads each destination deepest-first with one fresh listing GET, applying the
  same RDF parsing and body limits as preflight. It removes a container only when the listing is
  empty, its RDF passes the server-managed allow-list with no member subjects, and that GET has a
  usable strong ETag; DELETE sends that ETag in If-Match. Failed verification, GET or conditional
  DELETE preserves the container and its ancestors and reports a partial move. Destination
  containers are never deleted unconditionally during rollback. Every preflight failure after the
  first source GET discards its body before it can be handed to the destination PUT.
  Any source DELETE failure (including 4xx/5xx) throws conflict,
  cause = delete error. Retain acknowledged deleted sources' copies; before removing any other
  copy, HEAD its source without the caller's signal. Remove it only if HEAD succeeds; any HEAD
  failure (404, 5xx, network, scope, etc.) preserves the copy and its ancestor containers.
  Report a rolled-back move only when all copies were removed and no source deletion succeeded;
  otherwise report a partial move, including rollback failures. Cleanup ignores the spent caller
  signal, continues after failures, and reports original+rollback failures via AggregateError
  cause without masking them.
  Successful move returns target/created true and top create ETag; containers refresh it by HEAD
  when enabled (failure null).
- `setMetadata` reads metadata(url), scopes the describedby target, checks the metadata ETag (412
  with current ETag before PATCH), then computes deduplicated effective RDF changes. Anchor
  defaults to the resource and must be scoped; href must be an absolute IRI. Absolute IRI rels
  stay unchanged; registered `^[a-z][a-z0-9.-]*$` tokens (case-insensitive) lower-case into
  http://www.iana.org/assignments/relation/<rel>; invalid rel/href is TypeError. Add only absent,
  remove only present triples; cancelling changes are no-op and return the current ETag. Otherwise
  PATCH describedby with N3 and its If-Match; 405 naturally maps to method-not-allowed. Return its
  response ETag or follow-up HEAD of the metadata URL or null. No describedby remains unsupported.

- `WriteOptions.keepalive` / `CreateOptions.keepalive` reach fetch after the shared 64 KiB
  encoded-body check; unknown-size streams/Blobs fail bad-request before sending.
- `MetadataOp.title` sets `dct:title` on the anchor for add, and removes the exact literal for
  remove, using wrapper accessors and the existing N3 Patch builder. Titles accept quotes,
  newlines and Unicode as literal data. Emulated moves drop ACLs; `@jeswr/pod-access/roles` exports
  `movePreservingAccess` for the preserving variant (SDK-APP-04).
